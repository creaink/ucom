//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ChartDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHARTDEMO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_SERIESPROP_DLG              131
#define IDD_LINEPROP_DLG                135
#define IDD_SURFACEPROP_DLG             137
#define IDD_POINTPROP_DLG               139
#define IDC_CHARTCTRL                   1001
#define IDC_SERIES_GROUP                1007
#define IDC_ADDSERIES                   1009
#define IDC_SERIESNAME_EDIT             1010
#define IDC_SERIESTYPE_COMBO            1011
#define IDC_SERIESCOLOUR_BTN            1012
#define IDC_SERIES_LIST                 1013
#define IDC_GENERAL_GROUP               1014
#define IDC_LEGENDVIS_CHECK             1015
#define IDC_BKGND_COLBTN                1016
#define IDC_AXIS_GROUP                  1017
#define IDC_LEFTAXIS_RADIO              1018
#define IDC_BOTTOMAXIS_RADIO            1019
#define IDC_RIGHTAXIS_RADIO             1020
#define IDC_TOPAXIS_RADIO               1021
#define IDC_AXISVISIBLE_CHECK           1022
#define IDC_AXISAUTOMATIC_CHECK         1023
#define IDC_AXISGRIDVIS_CHECK           1024
#define IDC_AXISMINVAL_EDIT             1025
#define IDC_AXISMAXVAL_EDIT             1026
#define IDC_AXISLOGARITHMIC_CHECK       1027
#define IDC_AXISMINVAL_STATIC           1028
#define IDC_AXISMAXVAL_STATIC           1029
#define IDC_TITLE_EDIT                  1033
#define IDC_VERTICALAXIS_COMBO          1034
#define IDC_HORIZONTALAXIS_COMBO        1035
#define IDC_LINEDATA_RADIO              1036
#define IDC_SINEDATA_RADIO              1037
#define IDC_RANDOMDATA_RADIO            1038
#define IDC_MINXVALUE_EDIT              1039
#define IDC_MAXXVALUE_EDIT              1040
#define IDC_POINTSNUMBER_EDIT           1043
#define IDC_DATAPARAM1_EDIT             1044
#define IDC_DATAPARAM2_EDIT             1045
#define IDC_DATAPARAM1_TEXT             1046
#define IDC_DATAPARAM2_TEXT             1047
#define IDC_AXISINVERTED_CHECK          1048
#define IDC_AXISLABEL_EDIT              1049
#define IDC_DELETESERIES                1050
#define IDC_CHART2                      1052
#define IDC_PAN_CHECK                   1055
#define IDC_ZOOM_CHECK                  1056
#define IDC_PENSTYLE_COMBO              1058
#define IDC_LINEWIDTH_EDIT              1059
#define IDC_HORIZONTAL_RADIO            1060
#define IDC_RADIO2                      1061
#define IDC_FILLSTYLE_COMBO             1062
#define IDC_POINTTYPE_COMBO             1063
#define IDC_POINTWIDTH_EDIT             1064
#define IDC_POINTHEIGHT_EDIT            1065
#define IDC_CHECK1                      1066
#define IDC_AXISSCROLLBAR_CHECK         1066

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1067
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
